
# Redis-Based Test Data Management Solution

## Overview

This is an enterprise-grade solution for managing test data using **Redis** and **Spring Boot**. It provides REST APIs to perform the following operations on datasets:

1. **Save Records**: Insert data into Redis.
2. **Fetch Records**: Retrieve records with optional support for complex queries (`AND`, `OR` conditions).
3. **Delete Records**: Remove specific records using a unique identifier.
4. **Concurrency Safety**: Ensures data consistency using Redisson distributed locks.
5. **Requeue Logic**: Implements **pop-and-push** behavior to cycle fetched records back to the end of the queue.
6. **Support for Single and Multi-Dimensional Datasets**: Handles flexible schemas dynamically.

---

## Features

1. **Save Data**:
   - Supports both single and multi-dimensional datasets.
   - Automatically normalizes single-dimensional data for consistent querying.

2. **Fetch Data**:
   - Fetch records based on:
     - Empty conditions (defaults to the primary index).
     - Complex conditions using `AND` and `OR` logic.
   - Implements **pop-and-push** logic to ensure unique fetch behavior.
   - Skips reserved records to avoid duplicate sharing in concurrent environments.

3. **Delete Data**:
   - Removes records from Redis by their unique identifier.

4. **Concurrency Safety**:
   - Uses Redisson locks to handle concurrent access.

5. **Dynamic Configuration**:
   - Configurable parameters such as lock timeout, reservation timeout, and Redis key namespace.

---

## Requirements

- **Redis**: A Redis server instance for data storage.
- **Java 8+**: For running the Spring Boot application.
- **Maven**: For managing project dependencies.

---

## Technologies Used

1. **Spring Boot**: For building REST APIs.
2. **Redis**: For efficient and scalable data storage.
3. **Redisson**: For distributed locking and concurrency control.
4. **Docker (Optional)**: For containerizing Redis.

---

## Configuration

### **Redis Settings**

Add Redis server details in `application.yml` or `application.properties`:

```yaml
spring:
  redis:
    host: localhost
    port: 6379
```

### **Application-Specific Configurations**

Define constants in `application.yml`:

```yaml
redis:
  lock:
    timeout: 15 # Timeout for distributed locks (in seconds)
  reservation:
    timeout: 20 # Reservation timeout for fetched records (in seconds)
  key:
    namespace: "testdata:" # Namespace prefix for Redis keys
```

---

## Setup Instructions

### 1. **Clone the Repository**
```bash
git clone <repository-url>
cd <repository-folder>
```

### 2. **Start Redis**
If Redis is not already installed, you can run it using Docker:
```bash
docker run --name redis -p 6379:6379 -d redis
```

### 3. **Build and Run the Application**
```bash
mvn clean install
mvn spring-boot:run
```

---

## REST API Endpoints

### 1. **Save a Record**
- **URL**: `POST /api/records/{tableName}/save`
- **Description**: Saves a record in the specified dataset.

**Request Body Example**:
```json
{
    "uniqueId": "EPN123",
    "attributes": {
        "First Name": "John",
        "Last Name": "Doe",
        "Status": "Verified"
    }
}
```

---

### 2. **Fetch a Record**
- **URL**: `POST /api/records/{tableName}/fetch`
- **Description**: Fetches a record from the dataset. Supports optional query conditions.

**Request Body Example (Complex Query)**:
```json
{
    "AND": ["Verified"],
    "OR": ["Owner", "Contractor"]
}
```

**Response Example**:
```json
{
    "First Name": "John",
    "Last Name": "Doe",
    "Status": "Verified"
}
```

---

### 3. **Delete a Record**
- **URL**: `DELETE /api/records/{tableName}/delete/{uniqueId}`
- **Description**: Deletes a record by its unique identifier.

---

## Implementation Details

### **Pop-and-Push Logic**
- Records are removed (`ZREM`) from their current position in the Redis Sorted Set and re-added (`ZADD`) with a new score (current timestamp).
- Ensures a round-robin fetching behavior.

### **Query Logic**
- **Empty Conditions**:
  - Fetches all IDs from the primary index (`ZRANGE`).
- **OR Conditions**:
  - Performs a **union** of all matching condition sets.
- **AND Conditions**:
  - Computes an **intersection** of all matching condition sets.
- **Combination**:
  - Combines `AND` and `OR` results for flexible querying.

### **Concurrency Handling**
- Redisson distributed locks ensure that only one client can modify or reserve a record at a time.

---

## Future Enhancements

1. **Support for Bulk Operations**:
   - Batch insert, fetch, and delete operations.
2. **Metrics and Monitoring**:
   - Add Prometheus/Grafana integration for tracking API usage and performance.
3. **Audit Logging**:
   - Track changes made to datasets for better traceability.

---