package data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/records")
public class RecordController {

    private final RedisService redisService;

    @Autowired
    public RecordController(RedisService redisService) {
        this.redisService = redisService;
    }

    /**
     * Save a new record.
     *
     * @param tableName the dataset name (from path variable)
     * @param record    the record to save (from request body)
     * @return confirmation message
     */
    @PostMapping("/{tableName}/save")
    public ResponseEntity<String> saveRecord(@PathVariable String tableName, @RequestBody Record record) {
        redisService.saveRecord(tableName, record.getUniqueId(), record.getAttributes());
        return ResponseEntity.ok("Record saved successfully!");
    }

    /**
     * Fetch records based on query parameters.
     * Can fetch by uniqueId or by multiple attribute key-value pairs.
     *
     * @param tableName the dataset name (from path variable)
     * @param params    the query parameters for fetching
     * @return the fetched record or a no content message
     */
    @GetMapping("/{tableName}")
    public ResponseEntity<?> fetchRecord(
            @PathVariable String tableName,
            @RequestParam Map<String, String> params
    ) {
        if (params.containsKey("uniqueId")) {
            String uniqueId = params.get("uniqueId");
            Map<String, String> record = redisService.fetchAndReserveByUniqueId(tableName, uniqueId);
            if (record != null) {
                return ResponseEntity.ok(record);
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No records found with the provided uniqueId.");
            }
        } else if (!params.isEmpty()) {
            Map<String, String> attributes = params;
            Map<String, String> record = redisService.fetchAndReserveByAttributes(tableName, attributes);
            if (record != null) {
                return ResponseEntity.ok(record);
            } else {
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No records found matching the provided attributes.");
            }
        } else {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("No query parameters provided.");
        }
    }

    /**
     * Delete a specific record based on uniqueId.
     *
     * @param tableName the dataset name (from path variable)
     * @param uniqueId  the unique identifier for the record (from path variable)
     * @return confirmation message
     */
    @DeleteMapping("/{tableName}/delete/{uniqueId}")
    public ResponseEntity<String> deleteRecord(
            @PathVariable String tableName,
            @PathVariable String uniqueId
    ) {
        boolean isDeleted = redisService.deleteRecord(tableName, uniqueId);
        return isDeleted ?
                ResponseEntity.ok("Record deleted successfully.") :
                ResponseEntity.status(HttpStatus.NOT_FOUND).body("Record not found.");
    }
}
