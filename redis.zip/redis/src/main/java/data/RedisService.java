package data;

import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.TimeUnit;

@Service
public class RedisService {

    private static final Logger logger = LoggerFactory.getLogger(RedisService.class);

    private final RedisTemplate<String, Object> redisTemplate;
    private final RedisTemplate<String, String> stringRedisTemplate;
    private final HashOperations<String, String, Map<String, String>> hashOperations;
    private final ZSetOperations<String, String> zSetOperations;
    private final RedissonClient redissonClient;
    private final RedisConstantsConfig config;

    @Autowired
    public RedisService(
            RedisTemplate<String, Object> redisTemplate,
            RedisTemplate<String, String> stringRedisTemplate,
            RedissonClient redissonClient,
            RedisConstantsConfig config) {
        this.redisTemplate = redisTemplate;
        this.stringRedisTemplate = stringRedisTemplate;
        this.hashOperations = this.redisTemplate.opsForHash();
        this.zSetOperations = this.stringRedisTemplate.opsForZSet();
        this.redissonClient = redissonClient;
        this.config = config;
    }

    /**
     * Save a record to Redis.
     *
     * @param tableName  the dataset name
     * @param uniqueId   the unique identifier for the record
     * @param attributes the attributes of the record
     */
    public void saveRecord(String tableName, String uniqueId, Map<String, String> attributes) {
        String indexKey = config.redisNamespace + tableName + ":Index";
        String modifiedDateKey = config.redisNamespace + tableName + ":ModifiedDate";

        // Check if the uniqueId already exists in the primary index
        Double existingScore = zSetOperations.score(indexKey, uniqueId);
        if (existingScore != null) {
            logger.warn("uniqueId '{}' already exists in primary index '{}'. Skipping save operation.", uniqueId, indexKey);
            return;
        }

        long currentTime = System.currentTimeMillis();

        // Ensure uniqueId is included in attributes
        attributes.put("uniqueId", uniqueId);
        // Add modifiedDate to attributes
        attributes.put("modifiedDate", String.valueOf(currentTime));

        String hashKey = config.redisNamespace + tableName + ":ID:" + uniqueId;

        // Store the attributes map under the field "attributes" in Redis
        hashOperations.put(hashKey, "attributes", attributes);
        logger.info("Stored attributes for uniqueId '{}' under hashKey '{}'", uniqueId, hashKey);

        // Add to the primary index with the current timestamp as score (available for reservation)
        Boolean addedToPrimaryIndex = zSetOperations.add(indexKey, uniqueId, currentTime);
        if (Boolean.TRUE.equals(addedToPrimaryIndex)) {
            logger.info("Added uniqueId '{}' to primary index '{}'", uniqueId, indexKey);
        } else {
            logger.warn("Failed to add uniqueId '{}' to primary index '{}'", uniqueId, indexKey);
        }

        // Add to the modified date sorted set
        Boolean addedToModifiedDate = zSetOperations.add(modifiedDateKey, uniqueId, currentTime);
        if (Boolean.TRUE.equals(addedToModifiedDate)) {
            logger.info("Added uniqueId '{}' to modified date index '{}'", uniqueId, modifiedDateKey);
        } else {
            logger.warn("Failed to add uniqueId '{}' to modified date index '{}'", uniqueId, modifiedDateKey);
        }

        // Index the record by each value for value-only querying
        for (Map.Entry<String, String> entry : attributes.entrySet()) {
            String attributeName = entry.getKey();
            String attributeValue = entry.getValue().trim();

            // Skip indexing 'uniqueId' and 'modifiedDate'
            if ("uniqueId".equals(attributeName) || "modifiedDate".equals(attributeName)) {
                continue;
            }

            // Value-Only Condition Key with Attribute Name
            String conditionKeyValue = config.redisNamespace + tableName + ":Index:" + attributeName + ":" + attributeValue;
            Boolean addedToConditionIndexValue = zSetOperations.add(conditionKeyValue, uniqueId, currentTime);
            if (Boolean.TRUE.equals(addedToConditionIndexValue)) {
                logger.info("Indexed uniqueId '{}' under condition key '{}'", uniqueId, conditionKeyValue);
            } else {
                logger.warn("Failed to index uniqueId '{}' under condition key '{}'", uniqueId, conditionKeyValue);
            }
        }
    }

    /**
     * Fetch and reserve a record based on uniqueId.
     *
     * @param tableName the dataset name
     * @param uniqueId  the unique identifier for the record
     * @return the fetched record's attributes, or null if none found or already reserved
     */
    public Map<String, String> fetchAndReserveByUniqueId(String tableName, String uniqueId) {
        String indexKey = config.redisNamespace + tableName + ":Index";
        String modifiedDateKey = config.redisNamespace + tableName + ":ModifiedDate";
        String lockKey = config.redisNamespace + "Lock:" + tableName + ":Index";
        RLock lock = redissonClient.getLock(lockKey);

        try {
            if (lock.tryLock(config.lockTimeoutSeconds, config.lockTimeoutSeconds, TimeUnit.SECONDS)) {
                logger.info("Acquired lock '{}'", lockKey);

                // Check if the uniqueId exists in the primary index
                Double currentScore = zSetOperations.score(indexKey, uniqueId);
                if (currentScore == null) {
                    logger.warn("uniqueId '{}' does not exist in primary index '{}'.", uniqueId, indexKey);
                    return null;
                }

                long currentTime = System.currentTimeMillis();

                if (currentScore > currentTime) {
                    logger.info("uniqueId '{}' is currently reserved (score: {}).", uniqueId, currentScore);
                    return null;
                }

                String hashKey = config.redisNamespace + tableName + ":ID:" + uniqueId;
                @SuppressWarnings("unchecked")
                Map<String, String> record = (Map<String, String>) hashOperations.get(hashKey, "attributes");

                if (record != null) {
                    // Update modifiedDate regardless of 'reserved' being true or false
                    long newModifiedDate = currentTime;
                    record.put("modifiedDate", String.valueOf(newModifiedDate));
                    hashOperations.put(hashKey, "attributes", record);
                    logger.info("Updated 'modifiedDate' for record ID '{}' to '{}'", uniqueId, newModifiedDate);

                    // Update modifiedDate sorted set
                    Boolean updatedModifiedDate = zSetOperations.add(modifiedDateKey, uniqueId, newModifiedDate);
                    if (Boolean.TRUE.equals(updatedModifiedDate)) {
                        logger.info("Updated modified date index '{}' for uniqueId '{}'", modifiedDateKey, uniqueId);
                    } else {
                        logger.warn("Failed to update modified date index '{}' for uniqueId '{}'", modifiedDateKey, uniqueId);
                    }

                    return record; // Successful reservation
                } else {
                    logger.warn("Record ID '{}' not found in hash '{}'", uniqueId, hashKey);
                }
            } else {
                logger.warn("Could not acquire lock '{}'", lockKey);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Interrupted while trying to acquire lock '{}'", lockKey, e);
            throw new RuntimeException("Failed to acquire lock for fetching data.", e);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
                logger.info("Released lock '{}'", lockKey);
            }
        }
        return null; // No available unreserved record
    }

    /**
     * Fetch and reserve a record based on multiple attribute key-value pairs.
     *
     * @param tableName  the dataset name
     * @param attributes the attribute key-value pairs to match
     * @return the fetched record's attributes, or null if none found
     */
    public Map<String, String> fetchAndReserveByAttributes(String tableName, Map<String, String> attributes) {
        String indexKey = config.redisNamespace + tableName + ":Index";
        String modifiedDateKey = config.redisNamespace + tableName + ":ModifiedDate";
        String lockKey = config.redisNamespace + "Lock:" + tableName + ":Index";
        RLock lock = redissonClient.getLock(lockKey);

        try {
            if (lock.tryLock(config.lockTimeoutSeconds, config.lockTimeoutSeconds, TimeUnit.SECONDS)) {
                logger.info("Acquired lock '{}'", lockKey);

                Set<String> finalResultIds = new HashSet<>();

                // Handle conditions
                if (attributes == null || attributes.isEmpty()) {
                    finalResultIds = zSetOperations.range(indexKey, 0, -1);
                    logger.info("Fetched all IDs from primary index '{}': {}", indexKey, finalResultIds);
                } else {
                    // Process AND conditions: records must match all attribute key-value pairs
                    Set<String> andResultIds = null;
                    for (Map.Entry<String, String> entry : attributes.entrySet()) {
                        String attributeName = entry.getKey();
                        String attributeValue = entry.getValue().trim();
                        String conditionKey = config.redisNamespace + tableName + ":Index:" + attributeName + ":" + attributeValue;
                        Set<String> ids = zSetOperations.range(conditionKey, 0, -1);
                        if (ids != null && !ids.isEmpty()) {
                            if (andResultIds == null) {
                                andResultIds = new HashSet<>(ids);
                                logger.info("AND condition '{}:{}', initial IDs from '{}': {}", attributeName, attributeValue, conditionKey, ids);
                            } else {
                                andResultIds.retainAll(ids);
                                logger.info("AND condition '{}:{}', intersected IDs with '{}': {}", attributeName, attributeValue, conditionKey, andResultIds);
                            }
                        } else {
                            // If any condition yields no results, no need to proceed
                            andResultIds = Collections.emptySet();
                            logger.info("AND condition '{}:{}' yielded no results. Aborting.", attributeName, attributeValue);
                            break;
                        }
                    }

                    if (andResultIds != null) {
                        finalResultIds = andResultIds;
                    }
                    logger.info("Final result IDs after combining conditions: {}", finalResultIds);
                }

                // If no records match the conditions, return
                if (finalResultIds.isEmpty()) {
                    logger.info("No records found matching the conditions.");
                    return null;
                }

                // Fetch 'modifiedDate' for all matching uniqueIds
                List<String> sortedUniqueIds = new ArrayList<>(finalResultIds);
                // Fetch 'modifiedDate' scores
                Set<ZSetOperations.TypedTuple<String>> modifiedDateTuples = zSetOperations.rangeWithScores(modifiedDateKey, 0, -1);
                Map<String, Double> uniqueIdToModifiedDate = new HashMap<>();
                if (modifiedDateTuples != null) {
                    for (ZSetOperations.TypedTuple<String> tuple : modifiedDateTuples) {
                        String id = tuple.getValue();
                        double score = tuple.getScore();
                        if (finalResultIds.contains(id)) {
                            uniqueIdToModifiedDate.put(id, score);
                        }
                    }
                }

                // Sort uniqueIds by 'modifiedDate' ascending (oldest first)
                sortedUniqueIds.sort(Comparator.comparingDouble(uniqueIdToModifiedDate::get));

                logger.info("UniqueIds sorted by 'modifiedDate' ascending: {}", sortedUniqueIds);

                long currentTime = System.currentTimeMillis();

                // Iterate over sorted uniqueIds and find the first available to reserve
                for (String uniqueId : sortedUniqueIds) {
                    Double reservationScore = zSetOperations.score(indexKey, uniqueId);
                    if (reservationScore != null && reservationScore <= currentTime) {
                        // Attempt to reserve the record
                        String hashKey = config.redisNamespace + tableName + ":ID:" + uniqueId;
                        @SuppressWarnings("unchecked")
                        Map<String, String> record = (Map<String, String>) hashOperations.get(hashKey, "attributes");

                        if (record != null) {
                            // Update modifiedDate regardless of 'reserved' being true or false
                            long newModifiedDate = currentTime;
                            record.put("modifiedDate", String.valueOf(newModifiedDate));
                            hashOperations.put(hashKey, "attributes", record);
                            logger.info("Updated 'modifiedDate' for record ID '{}' to '{}'", uniqueId, newModifiedDate);

                            // Update modifiedDate sorted set
                            Boolean updatedModifiedDate = zSetOperations.add(modifiedDateKey, uniqueId, newModifiedDate);
                            if (Boolean.TRUE.equals(updatedModifiedDate)) {
                                logger.info("Updated modified date index '{}' for uniqueId '{}'", modifiedDateKey, uniqueId);
                            } else {
                                logger.warn("Failed to update modified date index '{}' for uniqueId '{}'", modifiedDateKey, uniqueId);
                            }

                            return record; // Successful reservation
                        } else {
                            logger.warn("Record ID '{}' not found in hash '{}'", uniqueId, hashKey);
                        }
                    } else {
                        logger.info("Record ID '{}' is reserved or score is null: {}", uniqueId, reservationScore);
                    }
                }

            } else {
                logger.warn("Could not acquire lock '{}'", lockKey);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Interrupted while trying to acquire lock '{}'", lockKey, e);
            throw new RuntimeException("Failed to acquire lock for fetching data.", e);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
                logger.info("Released lock '{}'", lockKey);
            }
        }
        return null; // No available unreserved records
    }

    /**
     * Delete a record by unique ID.
     *
     * @param tableName the dataset name
     * @param uniqueId  the unique identifier for the record
     * @return true if deletion was successful, false otherwise
     */
    public boolean deleteRecord(String tableName, String uniqueId) {
        String indexKey = config.redisNamespace + tableName + ":Index";
        String modifiedDateKey = config.redisNamespace + tableName + ":ModifiedDate";
        String lockKey = config.redisNamespace + "Lock:" + tableName + ":ID:" + uniqueId;
        RLock lock = redissonClient.getLock(lockKey);

        try {
            Boolean isLocked = lock.tryLock(config.lockTimeoutSeconds, config.lockTimeoutSeconds, TimeUnit.SECONDS);
            if (Boolean.TRUE.equals(isLocked)) {
                logger.info("Acquired lock '{}'", lockKey);
                String hashKey = config.redisNamespace + tableName + ":ID:" + uniqueId;
                @SuppressWarnings("unchecked")
                Map<String, String> record = (Map<String, String>) hashOperations.get(hashKey, "attributes");

                if (record != null) {
                    // Delete the record from Redis hash
                    Long deletedFromHash = hashOperations.delete(hashKey, "attributes");
                    boolean isDeletedFromHash = deletedFromHash != null && deletedFromHash > 0;
                    logger.info("Deleted record ID '{}' from hash '{}': {}", uniqueId, hashKey, isDeletedFromHash);

                    // Remove from primary index
                    Long removedFromPrimaryIndex = zSetOperations.remove(indexKey, uniqueId);
                    boolean isRemovedFromPrimaryIndex = removedFromPrimaryIndex != null && removedFromPrimaryIndex > 0;
                    logger.info("Removed record ID '{}' from primary index '{}': {}", uniqueId, indexKey, isRemovedFromPrimaryIndex);

                    // Remove from modified date sorted set
                    Long removedFromModifiedDate = zSetOperations.remove(modifiedDateKey, uniqueId);
                    boolean isRemovedFromModifiedDate = removedFromModifiedDate != null && removedFromModifiedDate > 0;
                    logger.info("Removed record ID '{}' from modified date index '{}': {}", uniqueId, modifiedDateKey, isRemovedFromModifiedDate);

                    // Remove from value-only condition indices
                    for (Map.Entry<String, String> entry : record.entrySet()) {
                        String attributeValue = entry.getValue().trim();
                        String conditionKeyValue = config.redisNamespace + tableName + ":Index:" + entry.getKey() + ":" + attributeValue;
                        Long removedFromConditionIndex = zSetOperations.remove(conditionKeyValue, uniqueId);
                        boolean isRemovedFromConditionIndex = removedFromConditionIndex != null && removedFromConditionIndex > 0;
                        logger.info("Removed record ID '{}' from condition index '{}': {}", uniqueId, conditionKeyValue, isRemovedFromConditionIndex);
                    }

                    return isDeletedFromHash && isRemovedFromPrimaryIndex && isRemovedFromModifiedDate;
                } else {
                    logger.warn("Record ID '{}' not found in hash '{}'", uniqueId, hashKey);
                }
            } else {
                logger.warn("Could not acquire lock '{}'", lockKey);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.error("Interrupted while trying to acquire lock '{}'", lockKey, e);
            throw new RuntimeException("Failed to acquire lock for deleting data.", e);
        } finally {
            if (lock.isHeldByCurrentThread()) {
                lock.unlock();
                logger.info("Released lock '{}'", lockKey);
            }
        }
        return false;
    }
}
