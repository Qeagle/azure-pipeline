package data;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RedisConstantsConfig {

    @Value("${redis.lock.timeout:10}")
    public int lockTimeoutSeconds; // Timeout for Redisson locks (in seconds)

    @Value("${redis.reservation.timeout:10}")
    public int reservationTimeoutSeconds; // Timeout for record reservation (in seconds)

    @Value("${redis.key.namespace:}")
    public String redisNamespace; // Namespace prefix for Redis keys
}
