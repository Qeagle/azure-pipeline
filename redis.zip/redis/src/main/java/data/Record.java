package data;

import lombok.Data;
import java.io.Serializable;
import java.util.Map;

@Data
public class Record implements Serializable {
    private static final long serialVersionUID = 1L;
    private String tableName; // Dataset name 
    private String uniqueId; // Unique identifier for each record (e.g., EPN, SAID)
    private Map<String, String> attributes; // Dynamic attributes for the record
}
